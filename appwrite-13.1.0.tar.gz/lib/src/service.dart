import 'client.dart';

class Service {
  final Client client;

  const Service(this.client);
}

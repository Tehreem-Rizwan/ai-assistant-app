part of '../../models.dart';

abstract class Model {
  Map<String, dynamic> toMap();
}
